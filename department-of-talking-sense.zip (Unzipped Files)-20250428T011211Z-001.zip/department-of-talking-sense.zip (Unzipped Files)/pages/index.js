import Head from 'next/head';
import { useState } from 'react';
import { FaInstagram, FaTiktok, FaYoutube } from 'react-icons/fa';

export default function Home() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-4 text-center">
      <Head>
        <title>Department Of Talking Sense</title>
      </Head>

      <h1 className="text-4xl font-bold text-black mb-4">Department Of Talking Sense</h1>
      <p className="text-lg text-gray-700 max-w-xl mb-8">
        A podcast that dives into honest conversations, life experiences, and everything in between — where making sense of the world is a community effort. Join us for upcoming episodes, projects, and behind-the-scenes moments.
      </p>

      <form 
        action="https://formspree.io/f/your-form-id" 
        method="POST" 
        className="bg-black p-8 rounded-2xl shadow-lg max-w-md w-full"
      >
        <input 
          type="text" 
          name="name" 
          placeholder="Name" 
          required
          value={formData.name}
          onChange={handleChange}
          className="w-full mb-4 p-3 rounded-lg border-none focus:ring-2 focus:ring-orange-500"
        />
        <input 
          type="email" 
          name="email" 
          placeholder="Email" 
          required
          value={formData.email}
          onChange={handleChange}
          className="w-full mb-4 p-3 rounded-lg border-none focus:ring-2 focus:ring-orange-500"
        />
        <input 
          type="tel" 
          name="phone" 
          placeholder="Phone Number" 
          required
          value={formData.phone}
          onChange={handleChange}
          className="w-full mb-6 p-3 rounded-lg border-none focus:ring-2 focus:ring-orange-500"
        />
        <button 
          type="submit" 
          className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg transition"
        >
          Notify Me
        </button>
      </form>

      <div className="flex space-x-6 mt-8">
        <a href="https://instagram.com/YOUR_INSTAGRAM_HANDLE" target="_blank" rel="noopener noreferrer">
          <FaInstagram size={30} className="text-orange-500 hover:text-orange-600" />
        </a>
        <a href="https://tiktok.com/@YOUR_TIKTOK_HANDLE" target="_blank" rel="noopener noreferrer">
          <FaTiktok size={30} className="text-orange-500 hover:text-orange-600" />
        </a>
        <a href="https://youtube.com/YOUR_YOUTUBE_CHANNEL" target="_blank" rel="noopener noreferrer">
          <FaYoutube size={30} className="text-orange-500 hover:text-orange-600" />
        </a>
      </div>

      <footer className="mt-8 text-gray-400 text-sm">
        &copy; {new Date().getFullYear()} Department Of Talking Sense
      </footer>
    </div>
  );
}