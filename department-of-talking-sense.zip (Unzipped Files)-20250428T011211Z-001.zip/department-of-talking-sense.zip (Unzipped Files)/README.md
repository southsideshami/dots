# Department Of Talking Sense - Landing Page

This is a minimal, vibrant landing page built with **Next.js** and **TailwindCSS** for the podcast **Department Of Talking Sense**.

## Features
- Collects Name, Email, and Phone Number
- Bright orange/black/white theme
- Social links (Instagram, TikTok, YouTube)
- Mobile responsive

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run development server:
   ```bash
   npm run dev
   ```

## Notes

- Replace the Formspree URL (`action` in form) with your actual Formspree form endpoint.
- Replace Instagram, TikTok, and YouTube links with your real handles.
- Deploy easily to [Vercel](https://vercel.com/).

---
Built with 💬 and 🔥